import icons from './icons.svg';
import './App.css';
import ReactDOM from 'react-dom/client'

function Welcome(props) {
  return (
    <div className="App">
      <header className="App-header">
        <img src={icons} className="App-logo" alt="logo"/>
        <h1>Welcome to {props.name}</h1>      
      </header>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
const element = <Welcome name="React"/>;
root.render(element);

export default Welcome;